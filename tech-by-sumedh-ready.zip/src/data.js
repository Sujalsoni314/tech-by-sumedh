export const PROFILE = {
  name: 'Sumedh Vasudev Sharma',
  brand: 'Tech By Sumedh',
  email: 'Techbysumedh314@gmail.com',
  phone: '7692897318',
  location: 'Indore, Madhya Pradesh, India',
};
